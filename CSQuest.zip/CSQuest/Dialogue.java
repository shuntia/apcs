package com.shuntia;

public class Dialogue {
    
}
