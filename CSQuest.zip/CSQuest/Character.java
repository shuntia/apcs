package com.shuntia;

public class Character {
    String name;
}
