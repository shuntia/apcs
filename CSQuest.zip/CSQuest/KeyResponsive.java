public interface KeyResponsive {
    public void keyPressed(java.awt.event.KeyEvent e);
    public void keyReleased(java.awt.event.KeyEvent e);
    public void keyTyped(java.awt.event.KeyEvent e);
}
