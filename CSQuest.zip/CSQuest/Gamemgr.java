package com.shuntia;

public class Gamemgr {
    static Player maincharacter;

}
