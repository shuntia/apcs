public class Logicmgr {
    
}
