package com.shuntia;

public class Datamgr {
    
}
