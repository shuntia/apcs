public class Settingsmgr {
    public static double scrollspeed;
}
