public class Interactable extends MapCharacter{
    Dialogue dialogue;
    public Interactable(String name) {
        super(name);
    }
}
